import Controller.*;
import Model.*;
import java.util.*;
public class SecuritySmokeTest {
  static int count=0;
  static void check(boolean ok,String name){if(!ok)throw new AssertionError(name);System.out.println("PASS: "+name);count++;}
  public static void main(String[] args)throws Exception{
    Main m=new Main();m.sqlite=new SQLite();m.auth=new AuthController(m);m.initializeData();
    if(args.length>0 && args[0].equals("seed"))return;
    char[] pw="GoodPass1!".toCharArray(), wrong="WrongPass1!".toCharArray();
    check(m.auth.register("demoTest",pw,pw),"Registration");
    check(m.sqlite.getUser("demoTest").getRole()==2,"Default client role");
    String hash=m.sqlite.getUser("demoTest").getPassword();
    check(!hash.equals(new String(pw)) && PasswordUtil.verify(pw,hash) && !PasswordUtil.hash(pw).equals(hash),"Salted password verification");
    check(!m.auth.register("demoTest",pw,pw),"Duplicate username rejected");
    check(!m.auth.register("bad name",pw,pw),"Invalid username rejected");
    check(!m.auth.register("weakTest","weak".toCharArray(),"weak".toCharArray()),"Weak password rejected");
    check(m.auth.login("demoTest",wrong)==null,"Wrong password rejected");
    AuthController.LoginResult last=m.auth.login("demoTest",pw);
    check(last!=null && "FAILED".equals(last.lastStatus) && last.lastAttempt!=null,"Prior attempt status");
    for(int i=0;i<4;i++)m.auth.login("demoTest",wrong);
    check(m.sqlite.getUser("demoTest").getRole()==2,"Four consecutive failures not locked");
    m.auth.login("demoTest",wrong);
    check(m.sqlite.getUser("demoTest").getRole()==1 && m.auth.login("demoTest",pw)==null,"Fifth failure disables account");
    check(m.sqlite.updateUserRole("demoTest",2) && m.auth.login("demoTest",pw)!=null,"Admin role restoration operation");
    check(AccessControl.canAccess(m.sqlite.getUser("demoTest"),"client") && !AccessControl.canAccess(m.sqlite.getUser("demoTest"),"admin") && !AccessControl.canAccess(null,"client"),"Role checks");
    check(!Validator.isValidStock("1.5") && !Validator.isValidStock("10001") && !Validator.isValidPrice(Double.NaN),"Numeric validation");
    m.sqlite.insertProduct("Demo Item",2,10.0);Product product=m.sqlite.listProducts().stream().filter(p->p.getName().equals("Demo Item")).findFirst().get();
    check(m.sqlite.purchaseProduct("demoTest",product.getId(),product.getName(),1),"Purchase succeeds");
    check(!m.sqlite.purchaseProduct("demoTest",product.getId(),product.getName(),2),"Insufficient stock rejected");
    check(m.sqlite.getHistory("demoTest").size()==1 && m.sqlite.getHistory("client2").isEmpty(),"Purchase history filtered by owner");
    check(m.sqlite.getLogs().stream().anyMatch(l->l.getEvent().equals("ACCOUNT_LOCKED")) && m.sqlite.getLogs().stream().anyMatch(l->l.getEvent().equals("VALIDATION_FAILURE")),"Security events recorded");
    m.initializeData();check(m.sqlite.getUser("demoTest")!=null && m.sqlite.getHistory("demoTest").size()==1,"Initialization preserves state");
    System.out.println(count+" checks passed");
  }
}
