package Controller;


import Model.History;
import Model.Logs;
import Model.Product;
import Model.User;
import View.Frame;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;



public class Main {
    
    public SQLite sqlite;
    public AuthController auth;
    
    public static void main(String[] args) {
        new Main().init();
    }
    
    public void init(){
        // Initialize a driver object
        sqlite = new SQLite();
        
        // Initialize Auth Controller
        auth = new AuthController(this);

        // Create a database
        sqlite.createNewDatabase();
        
        initializeData();
        // Initialize User Interface
        final Frame frame = new Frame();
        Thread.setDefaultUncaughtExceptionHandler((thread, throwable) -> {
            javax.swing.SwingUtilities.invokeLater(() -> {
                frame.resetToLogin();
                ErrorHandler.show(frame);
            });
        });
        frame.init(this);
    }

    public void initializeData() {
        sqlite.createHistoryTable();
        sqlite.createLogsTable();
        sqlite.createProductTable();
        sqlite.createUserTable();
        if (!sqlite.hasUsers()) {
            sqlite.addUser("admin", PasswordUtil.hash("qwerty1234".toCharArray()), 5);
            sqlite.addUser("manager", PasswordUtil.hash("qwerty1234".toCharArray()), 4);
            sqlite.addUser("staff", PasswordUtil.hash("qwerty1234".toCharArray()), 3);
            sqlite.addUser("client1", PasswordUtil.hash("qwerty1234".toCharArray()));
            sqlite.addUser("client2", PasswordUtil.hash("qwerty1234".toCharArray()));
            sqlite.addProduct("Antivirus", 5, 500.0);
            sqlite.addProduct("Firewall", 3, 1000.0);
            sqlite.addProduct("Scanner", 10, 100.0);
        }
    }

    public void log(String event, String username, String desc) {
        try {
            String safeEvent = (event == null || event.trim().isEmpty()) ? "NOTICE" : event.trim();
            String safeUser = (username == null || username.trim().isEmpty()) ? "unknown" : username.trim();
            String safeDesc = (desc == null) ? "" : desc;
            if (safeUser.length() > 100) {
                safeUser = safeUser.substring(0, 100);
            }
            if (safeDesc.length() > 100) {
                safeDesc = safeDesc.substring(0, 100);
            }
            String timestamp = new Timestamp(new Date().getTime()).toString();
            sqlite.addLogs(safeEvent, safeUser, safeDesc, timestamp);
        } catch (Exception ex) {
            // Do not crash application if logging fails
        }
    }
    
}