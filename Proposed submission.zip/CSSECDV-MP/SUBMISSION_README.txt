SECURITY Svcs — CSSECDV / ITSECWB

RUN: Extract the archive. Open a terminal in dist and run:
    java -jar CSSECDV.jar
The included database.db and lib/sqlite-jdbc-3.23.1.jar must stay with the distribution.
Java 8+ with desktop GUI and SQLite JDBC native support is required. Built/tested with Java 21, target Java 8. On NetBeans, open the project root and use the included SQLite JDBC dependency.

Demo usernames: admin (role 5), manager (4), staff (3), client1 (2), client2 (2).
Demo password for all: qwerty1234 (preserved from supplied source; for coursework only).
For new accounts, use strong passwords such as GoodPass1! with confirmation.

The original database contained sample plaintext credentials and an old schema; a clean demo database with hashed credentials was generated for this distribution. The original uploaded archive is unchanged. Data persists across starts. Keep backups before destructive tests. Run the program from dist to use its included database.

Changes made for submission: fixed password field types and username trimming; removed authentication and database debug output; implemented admin user actions and restricted log clearing; fixed stock parsing; made database initialization persistent; rebuilt JAR from current source. See Security Documentation for controls and caveats.

Verification: 18 backend smoke checks passed in a separate disposable database; the JAR was launched under a virtual display. Interactive demo cases and NetBeans IDE execution were not verified. Run the tests in tests/SecuritySmokeTest.java only in an empty temporary working directory, not against the submission database. See Test_Cases.pdf for expected manual demo cases.
